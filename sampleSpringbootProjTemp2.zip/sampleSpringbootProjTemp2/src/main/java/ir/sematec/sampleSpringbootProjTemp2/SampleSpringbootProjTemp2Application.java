package ir.sematec.sampleSpringbootProjTemp2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleSpringbootProjTemp2Application {

	public static void main(String[] args) {
		SpringApplication.run(SampleSpringbootProjTemp2Application.class, args);


	}

}
