package ir.sematec.sampleSpringbootProjTemp2;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

@Component
@Aspect
@Profile("dev")
public class EmployeeCRUDAspect {



    //@Around("execution(* ir.sematec.*.getEmployeeById(..))")
    @Around("execution(* ir.sematec.sampleSpringbootProjTemp2.*.*(..))")
    public void userAdvice( ProceedingJoinPoint joinPoint) throws Throwable{
        StopWatch watch = new StopWatch();
        watch.start();
        joinPoint.proceed();
        watch.stop();
        System.out.println("@Around: call took-"+ watch.getTotalTimeMillis()+" ms");

//        System.out.println("@Around: Before calculation-"+ new Date());
//        joinPoint.proceed();
//        System.out.println("@Around: After calculation-"+ new Date());
    }

    //    @Before("execution(* ir.sematec.*.getEmployeeById(..))")
//    public void logBeforeV1(JoinPoint joinPoint)
//    {
//        System.out.println("EmployeeCRUDAspect.logBeforeV1() : " + joinPoint.getSignature().getName());
//    }
//
    @Before("execution(* ir.sematec.sampleSpringbootProjTemp2.*.*(..))")
    public void logBeforeV2( JoinPoint joinPoint)
    {
        System.out.println("EmployeeCRUDAspect.logBeforeV2() : " + joinPoint.getSignature().getName());
    }
    //
    @After("execution(* ir.sematec.sampleSpringbootProjTemp2.*.*(..))")
    public void logAfterV1(JoinPoint joinPoint)
    {
        System.out.println("EmployeeCRUDAspect.logAfterV1() : " + joinPoint.getSignature().getName());
    }

//    @After("execution(* EmployeeManager.*(..))")
//    public void logAfterV2( JoinPoint joinPoint)
//    {
//        System.out.println("EmployeeCRUDAspect.logAfterV2() : " + joinPoint.getSignature().getName());
//    }
}
