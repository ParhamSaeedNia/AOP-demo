package ir.sematec.sampleSpringbootProjTemp2;


import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Service("serviceBean")
@Profile("dev")
public class SampleBean {



    public void getEmployeeById(Integer employeeId) {
        System.out.println("Method getEmployeeById() called");

    }
}
