package ir.sematec.sampleSpringbootProjTemp2;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampleSpringbootProjTemp2ApplicationTests {

	@Test
	void contextLoads() {
	}



	@Autowired
	private SampleBean business1;



	@Test
	public void invokeAOPStuff() {
		business1.getEmployeeById(65);
	}

}